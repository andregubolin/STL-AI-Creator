# STL AI Creator — Android source (v1.5.0)

Aplicativo Android em Kotlin + Jetpack Compose para criar modelos paramétricos simples e exportar STL binário. Interface em português/inglês.

## O que funciona nesta versão
- Interface Android nativa com alternância PT/EN.
- Entrada de texto e ditado usando o reconhecedor de fala disponível no aparelho.
- Anexação de imagem como referência visual.
- Interpretador paramétrico local para blocos e cilindros, com dimensões em milímetros.
- Pré-visualização isométrica em wireframe.
- Exportação de STL binário pelo seletor de documentos do Android.
- Compartilhamento do STL por qualquer aplicativo compatível.
- Não exige conta, assinatura, chave de API ou conexão com internet para gerar os modelos paramétricos incluídos.

## Limitações honestas da versão inicial
Esta é uma primeira versão funcional de protótipo, não um CAD completo nem um modelo de IA generativa multimodal. A interpretação local reconhece formas e dimensões básicas. A imagem anexada fica registrada como referência, mas ainda não é convertida automaticamente em geometria 3D. Não há ainda geração de mecanismos complexos, análise de resistência, montagem com múltiplas peças, malha a partir de fotografia ou integração remota com LLM. Essas funções exigem módulos adicionais e validação.

## Compilar APK
1. Instale Android Studio (versão compatível com Android Gradle Plugin 8.7.3), JDK 17 e Android SDK Platform 35.
2. Abra a pasta `stl-ai-creator` no Android Studio.
3. Aguarde a sincronização do Gradle.
4. Use **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. O APK de debug ficará normalmente em `app/build/outputs/apk/debug/app-debug.apk`.

Também é possível compilar no terminal, com Gradle instalado:

```bash
gradle assembleDebug
```

## Estrutura
- `app/src/main/java/.../MainActivity.kt`: interface, ditado, seleção de imagem, exportação e compartilhamento.
- `Mesh.kt`: gerador de malhas e gravação STL binária.
- `AndroidManifest.xml`: configuração Android e compartilhamento seguro via FileProvider.

## Próximas etapas recomendadas
1. Motor geométrico robusto (booleans, furos, filetes, roscas e múltiplos corpos).
2. Importação de imagem com fluxo de reconstrução assistida e confirmação de medidas.
3. Integração opcional com endpoint de IA compatível, com configuração pelo usuário e sem chave embutida no APK.
4. Verificação de malha (normais, faces degeneradas, watertight) e exportação de conjuntos.
5. Testes em impressoras e fatiadores reais.

## Gratuidade
O código e os recursos locais deste projeto não cobram pelo uso. Serviços externos de IA podem ter limites, exigir conexão ou deixar de oferecer plano gratuito; por isso não são necessários para o funcionamento do gerador paramétrico local.


## Versão 1.1.0 — geometrias paramétricas adicionais

O gerador offline agora interpreta comandos simples para criar:

- Bloco retangular (largura, profundidade e altura).
- Cilindro maciço (diâmetro e altura).
- Tubo (diâmetro externo, diâmetro interno e altura).
- Prisma hexagonal (medida entre faces e altura).
- Engrenagem didática simplificada (módulo, número de dentes e altura).

### Exemplos de comandos

- `bloco largura 60 profundidade 40 altura 5`
- `cilindro diâmetro 12 altura 30`
- `tubo diâmetro externo 20 diâmetro interno 10 altura 25`
- `prisma hexagonal largura 18 altura 8`
- `engrenagem módulo 2 dentes 24 altura 6`

### Limitações técnicas importantes

O interpretador local é determinístico e baseado em regras; não é um modelo de linguagem treinado. As imagens anexadas servem como referência visual e não são convertidas automaticamente em malhas 3D. A engrenagem tem perfil simplificado, não involuto, e não deve ser tratada como componente mecânico de precisão. Ainda não há operações booleanas gerais, roscas, validação avançada de malha, montagem cinemática ou integração com IA multimodal em nuvem. Antes de fabricar peças funcionais, verifique dimensões, folgas, resistência, orientação e fatiamento.


## Versão 1.3.0 — verificação básica de malha e STL ASCII

Novidades:
- Verificador estrutural de malha: conta triângulos degenerados, arestas abertas e arestas não-manifold.
- Indicação de malha fechada (watertight) para ajudar a identificar modelos que podem apresentar problemas no fatiador.
- Exportação STL ASCII, além da exportação STL binária já existente.
- Versão Android atualizada para 1.3.0.

### Testes executados nesta entrega
O módulo geométrico e o verificador foram compilados isoladamente com `kotlinc`. Os cinco geradores atuais (bloco, cilindro, tubo, prisma hexagonal e engrenagem simplificada) foram inspecionados: todos apresentaram zero triângulos degenerados, zero arestas abertas e zero arestas não-manifold no teste local. Isso valida a conectividade básica das malhas testadas, mas não substitui abrir o STL em um fatiador, validar orientação/normais, espessuras mínimas, tolerâncias ou imprimir uma peça de teste.

### Limitações mantidas
O verificador não é um reparador de malha nem um simulador de impressão. O app ainda não converte imagens em malhas 3D, não possui IA multimodal conectada, operações booleanas, roscas, perfis involutos industriais, análise estrutural ou montagens cinemáticas. A IA local atual é um interpretador por regras, não um LLM.


## Novidades da versão 1.3.0
- Exportação de pacote ZIP com STL binário, STL ASCII, desenho técnico 3D em PDF, metadados JSON e README.
- Metadados incluem tipo e dimensões do modelo, número de triângulos e resumo da validação de arestas.
- Relatório de validação é limpo ao modificar as dimensões ou gerar outro modelo, evitando exibir um resultado antigo.
- A exportação ZIP usa o seletor de documentos do Android e pode ser salva ou compartilhada pelo usuário.

**Limite da validação:** o teste de estanqueidade verifica incidência de arestas; não detecta autointerseções nem substitui a análise do fatiador.


## Versão 1.4.0 — desenho técnico em PDF

Novidades:
- Geração de uma prancha PDF A4 horizontal para cada modelo criado.
- Vista isométrica vetorial desenhada diretamente a partir dos triângulos da malha STL.
- Vistas frontal, superior e lateral com dimensões do envelope X/Y/Z. Essas vistas são representações do envelope dimensional, não projeções CAD detalhadas de cada contorno.
- Quadro com tipo de modelo, quantidade de triângulos e resultado da verificação básica de arestas.
- Novo comando para exportar o PDF individualmente.
- O PDF também é incluído automaticamente no pacote ZIP completo, em `drawing/desenho_tecnico_3d.pdf`.

**Importante:** o PDF é um desenho técnico de referência gerado a partir da malha e das dimensões. Não contém tolerâncias, ajustes, rugosidade, especificações de material ou certificação para fabricação. Para peças funcionais, conferir cotas e geometria no CAD e no fatiador antes de imprimir.


## Versão 1.5.0 — projeções ortográficas da malha no PDF

- As vistas frontal, superior e lateral agora são desenhadas a partir das arestas reais dos triângulos da malha STL, em vez de apenas retângulos representando o envelope.
- Cada vista é ajustada à sua área e recebe dimensões X/Y/Z correspondentes.
- O desenho informa explicitamente que arestas ocultas também são exibidas; portanto, são projeções técnicas de referência, não vistas CAD com remoção automática de linhas ocultas.
- O PDF atualizado continua incluído no ZIP completo e também pode ser exportado individualmente.

**Limitação:** o gerador ainda não possui operações booleanas gerais para subtrair furos de placas ou criar rasgos de montagem arbitrários. Não interpretar linhas sobrepostas nas vistas como remoção de arestas ocultas.

## Gerar o APK automaticamente (sem Android Studio)

O projeto inclui o workflow `.github/workflows/android-apk.yml`. Ele compila um APK de depuração usando GitHub Actions e publica o arquivo como artefato para download.

1. Extraia este ZIP e envie o conteúdo da pasta `stl-ai-creator` para um repositório GitHub seu (a pasta `.github` precisa ser incluída).
2. No GitHub, abra a aba **Actions** e selecione **Build STL AI Creator APK**.
3. Se necessário, toque em **Run workflow** e confirme em **Run workflow**.
4. Aguarde o trabalho terminar com o indicador verde.
5. Abra a execução concluída e baixe o artefato **STL-AI-Creator-debug-APK**.
6. Extraia o ZIP do artefato no celular e toque em `app-debug.apk` para instalar.

O APK gerado é uma compilação **debug**, assinada automaticamente com a chave de depuração do processo de build. Não é uma versão de publicação na Play Store. O GitHub Actions exige uma conta GitHub e conexão com a internet. O artefato fica disponível por 14 dias.

### Requisitos de compilação

- JDK 17
- Gradle 8.9
- Android SDK Platform 35 e Build Tools 35.0.0

A compilação deve ser considerada confirmada somente depois que o workflow terminar com sucesso e o artefato APK estiver disponível.
