package com.stlaicreator.app

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.speech.RecognizerIntent
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.FileProvider
import java.io.File
import java.io.FileOutputStream
import java.io.ByteArrayOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream
import java.util.Locale

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { CreatorScreen() }
    }

    @Composable private fun CreatorScreen() {
        var prompt by remember { mutableStateOf("Crie um bloco com largura 40, profundidade 30 e altura 20 mm") }
        var language by remember { mutableStateOf("pt") }
        var request by remember { mutableStateOf(LocalDesignAI.interpret(prompt)) }
        var mesh by remember { mutableStateOf(LocalDesignAI.build(request)) }
        var status by remember { mutableStateOf("Pronto para criar") }
        var meshReport by remember { mutableStateOf<MeshReport?>(null) }
        var attachedImage by remember { mutableStateOf<Uri?>(null) }
        val isPt = language=="pt"
        val imagePicker=rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { attachedImage=it; if(it!=null) status=if(isPt) "Imagem anexada como referência visual." else "Image attached as visual reference." }
        val speech=rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            val spoken=result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
            if(!spoken.isNullOrBlank()) prompt=spoken
        }
        val saveStl=rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("model/stl")) { uri ->
            if(uri!=null) try { contentResolver.openOutputStream(uri)?.use { mesh.writeBinaryStl(it,"stl-ai-creator") }; status=if(isPt) "STL exportado com sucesso." else "STL exported successfully." } catch(e:Exception) { status=e.message ?: "Export error" }
        }
        val savePdf=rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/pdf")) { uri ->
            if(uri!=null) try {
                val report=MeshValidator.inspect(mesh)
                val pdf=TechnicalDrawingPdf.create(mesh,request,language,report)
                contentResolver.openOutputStream(uri)?.use { it.write(pdf) }
                status=if(isPt) "Desenho técnico PDF exportado." else "Technical drawing PDF exported."
            } catch(e:Exception) { status=e.message ?: "PDF export error" }
        }
        val saveProject=rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/zip")) { uri ->
            if(uri!=null) try {
                val report=MeshValidator.inspect(mesh)
                val binary=ByteArrayOutputStream().also { mesh.writeBinaryStl(it,"stl-ai-creator") }.toByteArray()
                val ascii=buildString {
                    append("solid stl_ai_creator\n")
                    mesh.triangles.forEach { t ->
                        val n=(t.b-t.a).cross(t.c-t.a).normalized()
                        append(" facet normal ${n.x} ${n.y} ${n.z}\n  outer loop\n")
                        listOf(t.a,t.b,t.c).forEach { v -> append("   vertex ${v.x} ${v.y} ${v.z}\n") }
                        append("  endloop\n endfacet\n")
                    }
                    append("endsolid stl_ai_creator\n")
                }
                val pdf=TechnicalDrawingPdf.create(mesh,request,language,report)
                val metadata="""{
  "application": "STL AI Creator",
  "version": "1.5.0",
  "language": "$language",
  "model_type": "${request.type}",
  "dimensions_mm": {"x": ${request.x}, "y": ${request.y}, "z": ${request.z}},
  "description": "${mesh.description.replace("\"", "'")}",
  "triangles": ${mesh.triangles.size},
  "degenerate_triangles": ${report.degenerateTriangles},
  "boundary_edges": ${report.boundaryEdges},
  "non_manifold_edges": ${report.nonManifoldEdges},
  "watertight_by_edge_test": ${report.isWatertight}
}\n"""
                contentResolver.openOutputStream(uri)?.use { raw -> ZipOutputStream(raw).use { zip ->
                    fun entry(name:String,bytes:ByteArray) { zip.putNextEntry(ZipEntry(name)); zip.write(bytes); zip.closeEntry() }
                    entry("model/model_binary.stl",binary)
                    entry("model/model_ascii.stl",ascii.toByteArray(Charsets.UTF_8))
                    entry("drawing/desenho_tecnico_3d.pdf",pdf)
                    entry("project/project.json",metadata.toByteArray(Charsets.UTF_8))
                    entry("README.txt",("STL AI Creator 1.5.0\n\nPacote do projeto com STL binário, STL ASCII, desenho técnico 3D em PDF e metadados de dimensões/validação.\nO PDF contém vista isométrica da malha e vistas ortográficas projetadas a partir das arestas da malha (incluindo arestas ocultas).\nA verificação de estanqueidade considera incidência de arestas e não substitui a análise no fatiador.\n").toByteArray(Charsets.UTF_8))
                } }
                status=if(isPt) "Pacote ZIP do projeto exportado." else "Project ZIP package exported."
            } catch(e:Exception) { status=e.message ?: "Project export error" }
        }
        val saveAscii=rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("model/stl")) { uri ->
            if(uri!=null) try {
                contentResolver.openOutputStream(uri)?.bufferedWriter()?.use { out ->
                    out.append("solid stl_ai_creator\n")
                    mesh.triangles.forEach { t ->
                        val n=(t.b-t.a).cross(t.c-t.a).normalized()
                        out.append(" facet normal ${n.x} ${n.y} ${n.z}\n  outer loop\n")
                        listOf(t.a,t.b,t.c).forEach { v -> out.append("   vertex ${v.x} ${v.y} ${v.z}\n") }
                        out.append("  endloop\n endfacet\n")
                    }
                    out.append("endsolid stl_ai_creator\n")
                }
                status=if(isPt) "STL ASCII exportado." else "ASCII STL exported."
            } catch(e:Exception) { status=e.message ?: "Export error" }
        }
        MaterialTheme(colorScheme=darkColorScheme(primary=Color(0xFF9B8CFF),secondary=Color(0xFF43D9C5),background=Color(0xFF10111A),surface=Color(0xFF1A1C29))) {
            Surface(Modifier.fillMaxSize(), color=MaterialTheme.colorScheme.background) {
                Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(18.dp), verticalArrangement=Arrangement.spacedBy(14.dp)) {
                    Row(verticalAlignment=Alignment.CenterVertically, horizontalArrangement=Arrangement.SpaceBetween, modifier=Modifier.fillMaxWidth()) {
                        Column { Text("STL AI Creator", style=MaterialTheme.typography.headlineSmall, fontWeight=FontWeight.Bold); Text(if(isPt) "IDEIAS → MODELOS 3D → STL" else "IDEAS → 3D MODELS → STL", color=Color.LightGray, style=MaterialTheme.typography.labelSmall) }
                        TextButton(onClick={language=if(isPt) "en" else "pt"}) { Text(if(isPt) "EN" else "PT") }
                    }
                    Card(colors=CardDefaults.cardColors(containerColor=Color(0xFF202338))) {
                        Column(Modifier.padding(14.dp), verticalArrangement=Arrangement.spacedBy(10.dp)) {
                            Text(if(isPt) "Descreva seu projeto" else "Describe your project", fontWeight=FontWeight.SemiBold)
                            OutlinedTextField(value=prompt,onValueChange={prompt=it},modifier=Modifier.fillMaxWidth(),minLines=3,placeholder={Text(if(isPt) "Ex.: suporte de 60 × 40 × 5 mm" else "E.g. 60 × 40 × 5 mm bracket")})
                            Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                                OutlinedButton(onClick={ imagePicker.launch("image/*") }, modifier=Modifier.weight(1f)) { Text(if(isPt) "Anexar imagem" else "Attach image") }
                                OutlinedButton(onClick={ try { speech.launch(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM).putExtra(RecognizerIntent.EXTRA_LANGUAGE,if(isPt) "pt-BR" else "en-US")) } catch(_:Exception) { status=if(isPt) "Reconhecimento de voz indisponível." else "Speech recognition unavailable." } },modifier=Modifier.weight(1f)) { Text(if(isPt) "Ditado 🎙" else "Voice 🎙") }
                            }
                            attachedImage?.let { Text((if(isPt) "Referência anexada: " else "Attached reference: ")+it.lastPathSegment, color=Color(0xFF43D9C5), style=MaterialTheme.typography.bodySmall) }
                            Button(onClick={ request=LocalDesignAI.interpret(prompt); mesh=LocalDesignAI.build(request); meshReport=null; status=if(isPt) "Modelo paramétrico criado localmente." else "Parametric model created locally." },modifier=Modifier.fillMaxWidth()) { Text(if(isPt) "GERAR MODELO 3D" else "GENERATE 3D MODEL") }
                        }
                    }
                    Text(if(isPt) "Pré-visualização 3D" else "3D preview", fontWeight=FontWeight.SemiBold)
                    Card(colors=CardDefaults.cardColors(containerColor=Color(0xFF171A27))) {
                        Column(Modifier.padding(12.dp)) {
                            MeshPreview(mesh)
                            Text(mesh.description, color=Color.LightGray, style=MaterialTheme.typography.bodySmall)
                        }
                    }
                    Text(if(isPt) "Dimensões (mm)" else "Dimensions (mm)", fontWeight=FontWeight.SemiBold)
                    Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                        DimensionField(if(isPt) "Largura / Ø" else "Width / Ø",request.x) { request=request.copy(x=it); mesh=LocalDesignAI.build(request); meshReport=null }
                        if(request.type=="box") DimensionField(if(isPt) "Profundidade" else "Depth",request.y) { request=request.copy(y=it); mesh=LocalDesignAI.build(request); meshReport=null }
                        if(request.type=="tube") DimensionField(if(isPt) "Ø interno" else "Inner Ø",request.y) { request=request.copy(y=it); mesh=runCatching { LocalDesignAI.build(request) }.getOrElse { mesh }; meshReport=null }
                        if(request.type=="gear") DimensionField(if(isPt) "Dentes" else "Teeth",request.y) { request=request.copy(y=it.coerceIn(6f,100f)); mesh=runCatching { LocalDesignAI.build(request) }.getOrElse { mesh }; meshReport=null }
                        DimensionField(if(isPt) "Altura" else "Height",request.z) { request=request.copy(z=it); mesh=LocalDesignAI.build(request); meshReport=null }
                    }
                    Row(horizontalArrangement=Arrangement.spacedBy(10.dp)) {
                        Button(onClick={ meshReport=MeshValidator.inspect(mesh); status=meshReport!!.summaryPortuguese() },modifier=Modifier.weight(1f)) { Text(if(isPt) "Verificar malha" else "Check mesh") }
                        OutlinedButton(onClick={saveAscii.launch("projeto_stl_ai_creator_ascii.stl")},modifier=Modifier.weight(1f)) { Text(if(isPt) "STL ASCII" else "ASCII STL") }
                    }
                    meshReport?.let { report ->
                        Card(colors=CardDefaults.cardColors(containerColor=if(report.isWatertight) Color(0xFF17352F) else Color(0xFF3A2B20))) {
                            Text(if(isPt) report.summaryPortuguese() else "Faces: ${report.triangleCount} | Degenerate: ${report.degenerateTriangles} | Open edges: ${report.boundaryEdges} | Non-manifold: ${report.nonManifoldEdges} | ${if(report.isWatertight) "Watertight" else "Not watertight"}", modifier=Modifier.padding(12.dp), style=MaterialTheme.typography.bodySmall)
                        }
                    }
                    OutlinedButton(onClick={ savePdf.launch("STL_AI_Creator_desenho_tecnico.pdf") }, modifier=Modifier.fillMaxWidth()) {
                        Text(if(isPt) "EXPORTAR DESENHO TÉCNICO 3D (PDF)" else "EXPORT 3D TECHNICAL DRAWING (PDF)")
                    }
                    OutlinedButton(onClick={ saveProject.launch("STL_AI_Creator_projeto.zip") }, modifier=Modifier.fillMaxWidth()) {
                        Text(if(isPt) "EXPORTAR PROJETO COMPLETO (ZIP + PDF)" else "EXPORT COMPLETE PROJECT (ZIP + PDF)")
                    }
                    Row(horizontalArrangement=Arrangement.spacedBy(10.dp)) {
                        Button(onClick={saveStl.launch("projeto_stl_ai_creator.stl")},modifier=Modifier.weight(1f)) { Text("↓ STL Binário") }
                        OutlinedButton(onClick={
                            try {
                                val dir=File(cacheDir,"models").apply{mkdirs()}; val file=File(dir,"projeto_stl_ai_creator.stl")
                                FileOutputStream(file).use { mesh.writeBinaryStl(it,"stl-ai-creator") }
                                val uri=FileProvider.getUriForFile(this@MainActivity,"$packageName.provider",file)
                                startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply { type="model/stl"; putExtra(Intent.EXTRA_STREAM,uri); addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION) },if(isPt) "Compartilhar STL" else "Share STL"))
                            } catch(e:Exception) { status=e.message ?: "Share error" }
                        },modifier=Modifier.weight(1f)) { Text(if(isPt) "Compartilhar" else "Share") }
                    }
                    Card(colors=CardDefaults.cardColors(containerColor=Color(0xFF202338))) { Column(Modifier.padding(12.dp),verticalArrangement=Arrangement.spacedBy(4.dp)) {
                        Text(if(isPt) "IA híbrida • modo local ativo" else "Hybrid AI • local mode active",fontWeight=FontWeight.SemiBold,color=Color(0xFF43D9C5))
                        Text(if(isPt) "O modo local gera blocos, cilindros, tubos, prismas hexagonais e engrenagens simplificadas. Imagens são referências, não conversão automática em 3D. Engrenagens não usam perfil involuto e peças roscadas/assemblies ainda não são suportadas. A IA online multimodal será integrada em uma etapa posterior." else "Local mode generates boxes, cylinders, tubes, hexagonal prisms and simplified gears. Images are references, not automatic 3D conversion. Gears are not involute and threaded parts/assemblies are not yet supported. Online multimodal AI will be integrated in a later stage.",style=MaterialTheme.typography.bodySmall,color=Color.LightGray)
                    } }
                    Text(status,color=Color(0xFF43D9C5),style=MaterialTheme.typography.bodySmall)
                    Text("v1.5.0 • Android • PT / EN",color=Color.Gray,style=MaterialTheme.typography.labelSmall)
                }
            }
        }
    }

    @Composable private fun DimensionField(label:String,value:Float,onValue:(Float)->Unit) {
        var text by remember(value) { mutableStateOf(value.toString().removeSuffix(".0")) }
        OutlinedTextField(value=text,onValueChange={text=it;it.replace(',','.').toFloatOrNull()?.let { n -> if(n in 1f..500f) onValue(n) }},label={Text(label)},modifier=Modifier.width(112.dp),singleLine=true)
    }

    @Composable private fun MeshPreview(mesh:Mesh) {
        Canvas(Modifier.fillMaxWidth().height(210.dp)) {
            val all=mesh.triangles.flatMap { listOf(it.a,it.b,it.c) }
            if(all.isEmpty()) return@Canvas
            val maxX=all.maxOf { kotlin.math.abs(it.x) }.coerceAtLeast(1f); val maxY=all.maxOf { kotlin.math.abs(it.y) }.coerceAtLeast(1f); val maxZ=all.maxOf { it.z }.coerceAtLeast(1f)
            val scale=(size.minDimension*.30f)/(maxX+maxY+maxZ*.7f).coerceAtLeast(1f)
            fun project(v:V3)=Offset(size.width/2+(v.x-v.y)*scale*.85f,size.height*.70f-(v.x+v.y)*scale*.42f-v.z*scale)
            // Draw all facets with a restrained isometric wireframe; suitable for preview, not CAD inspection.
            mesh.triangles.forEach { t ->
                val p=Path().apply { moveTo(project(t.a).x,project(t.a).y);lineTo(project(t.b).x,project(t.b).y);lineTo(project(t.c).x,project(t.c).y);close() }
                drawPath(p,Color(0xFF8274E8).copy(alpha=.10f))
                drawPath(p,Color(0xFF9D91FF).copy(alpha=.65f),style=Stroke(width=1f))
            }
        }
    }
}
