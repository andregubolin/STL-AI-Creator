package com.stlaicreator.app

import kotlin.math.abs
import kotlin.math.roundToLong

/** Structural checks for triangle meshes before STL export. This is not a slicer simulation. */
data class MeshReport(
    val triangleCount: Int,
    val degenerateTriangles: Int,
    val boundaryEdges: Int,
    val nonManifoldEdges: Int,
    val isWatertight: Boolean
) {
    fun summaryPortuguese(): String = buildString {
        append("Faces: $triangleCount | Triângulos degenerados: $degenerateTriangles | ")
        append("Arestas abertas: $boundaryEdges | Arestas não-manifold: $nonManifoldEdges | ")
        append(if (isWatertight) "Malha fechada" else "Malha não fechada")
    }
}

object MeshValidator {
    private data class PointKey(val x: Long, val y: Long, val z: Long) : Comparable<PointKey> {
        override fun compareTo(other: PointKey): Int = compareValuesBy(this, other, PointKey::x, PointKey::y, PointKey::z)
    }
    private data class EdgeKey(val a: PointKey, val b: PointKey)

    // Quantization avoids tiny float differences causing the same intended vertex to be counted twice.
    private fun key(v: V3): PointKey = PointKey(
        (v.x * 10_000f).roundToLong(),
        (v.y * 10_000f).roundToLong(),
        (v.z * 10_000f).roundToLong()
    )

    fun inspect(mesh: Mesh): MeshReport {
        val edges = HashMap<EdgeKey, Int>()
        var degenerate = 0
        fun addEdge(p: V3, q: V3) {
            val a = key(p); val b = key(q)
            val edge = if (a <= b) EdgeKey(a, b) else EdgeKey(b, a)
            edges[edge] = (edges[edge] ?: 0) + 1
        }
        mesh.triangles.forEach { t ->
            val area2 = (t.b - t.a).cross(t.c - t.a)
            if (abs(area2.x) + abs(area2.y) + abs(area2.z) < 1e-7f) degenerate++
            addEdge(t.a, t.b); addEdge(t.b, t.c); addEdge(t.c, t.a)
        }
        val boundary = edges.values.count { it == 1 }
        val nonManifold = edges.values.count { it > 2 || it < 1 }
        return MeshReport(
            triangleCount = mesh.triangles.size,
            degenerateTriangles = degenerate,
            boundaryEdges = boundary,
            nonManifoldEdges = nonManifold,
            isWatertight = mesh.triangles.isNotEmpty() && degenerate == 0 && boundary == 0 && nonManifold == 0
        )
    }
}
