package com.stlaicreator.app

import java.io.DataOutputStream
import java.io.OutputStream
import kotlin.math.*

data class V3(val x: Float, val y: Float, val z: Float) {
    operator fun minus(o: V3) = V3(x-o.x, y-o.y, z-o.z)
    fun cross(o: V3) = V3(y*o.z-z*o.y, z*o.x-x*o.z, x*o.y-y*o.x)
    fun normalized(): V3 { val n=sqrt(x*x+y*y+z*z); return if(n==0f) V3(0f,0f,0f) else V3(x/n,y/n,z/n) }
}
data class Triangle(val a: V3, val b: V3, val c: V3)

data class Mesh(val triangles: List<Triangle>, val description: String) {
    fun writeBinaryStl(out: OutputStream, name: String) {
        require(triangles.isNotEmpty()) { "O modelo não possui faces." }
        require(triangles.size <= Int.MAX_VALUE / 50) { "Modelo muito grande para STL binário." }
        val data = DataOutputStream(out)
        val header = ("STL AI Creator - $name").toByteArray(Charsets.US_ASCII).take(80).toByteArray()
        data.write(header); repeat(80-header.size) { data.writeByte(0) }
        data.writeInt(Integer.reverseBytes(triangles.size))
        triangles.forEach { t ->
            val n=(t.b-t.a).cross(t.c-t.a).normalized()
            listOf(n,t.a,t.b,t.c).forEach { v ->
                data.writeInt(Integer.reverseBytes(java.lang.Float.floatToIntBits(v.x)))
                data.writeInt(Integer.reverseBytes(java.lang.Float.floatToIntBits(v.y)))
                data.writeInt(Integer.reverseBytes(java.lang.Float.floatToIntBits(v.z)))
            }
            data.writeShort(0)
        }
        data.flush()
    }
}

object ModelBuilder {
    private fun quad(a:V3,b:V3,c:V3,d:V3)=listOf(Triangle(a,b,c),Triangle(a,c,d))
    fun box(x: Float, y: Float, z: Float): Mesh {
        val a=V3(-x/2,-y/2,0f); val b=V3(x/2,-y/2,0f); val c=V3(x/2,y/2,0f); val d=V3(-x/2,y/2,0f)
        val e=V3(-x/2,-y/2,z); val f=V3(x/2,-y/2,z); val g=V3(x/2,y/2,z); val h=V3(-x/2,y/2,z)
        val faces=listOf(listOf(a,d,c,b),listOf(e,f,g,h),listOf(a,b,f,e),listOf(b,c,g,f),listOf(c,d,h,g),listOf(d,a,e,h))
        return Mesh(faces.flatMap { q -> listOf(Triangle(q[0],q[1],q[2]),Triangle(q[0],q[2],q[3])) }, "Bloco ${x}×${y}×${z} mm")
    }
    fun cylinder(diameter: Float, height: Float, segments: Int=64): Mesh {
        val r=diameter/2; val bottom=V3(0f,0f,0f); val top=V3(0f,0f,height); val tris=mutableListOf<Triangle>()
        for(i in 0 until segments) {
            val a=2*Math.PI*i/segments; val b=2*Math.PI*(i+1)/segments
            val p=V3((r*cos(a)).toFloat(),(r*sin(a)).toFloat(),0f); val q=V3((r*cos(b)).toFloat(),(r*sin(b)).toFloat(),0f)
            val pt=V3(p.x,p.y,height); val qt=V3(q.x,q.y,height)
            tris += Triangle(bottom,q,p); tris += Triangle(top,pt,qt); tris += Triangle(p,q,qt); tris += Triangle(p,qt,pt)
        }
        return Mesh(tris,"Cilindro maciço Ø${diameter} × ${height} mm")
    }
    fun tube(outerDiameter:Float, innerDiameter:Float, height:Float, segments:Int=72):Mesh {
        require(innerDiameter>0f && innerDiameter<outerDiameter) { "O diâmetro interno deve ser maior que zero e menor que o externo." }
        val ro=outerDiameter/2; val ri=innerDiameter/2; val tris=mutableListOf<Triangle>()
        for(i in 0 until segments) {
            val a=2*PI*i/segments; val b=2*PI*(i+1)/segments
            fun v(r:Float,t:Double,z:Float)=V3((r*cos(t)).toFloat(),(r*sin(t)).toFloat(),z)
            val ob=v(ro,a,0f); val ob2=v(ro,b,0f); val ot=v(ro,a,height); val ot2=v(ro,b,height)
            val ib=v(ri,a,0f); val ib2=v(ri,b,0f); val it=v(ri,a,height); val it2=v(ri,b,height)
            tris += quad(ob,ob2,ot2,ot); tris += quad(ib,it,it2,ib2)
            tris += quad(ot,ot2,it2,it); tris += quad(ob,ib,ib2,ob2)
        }
        return Mesh(tris,"Tubo Ø externo ${outerDiameter} mm, Ø interno ${innerDiameter} mm, altura ${height} mm")
    }
    fun hexPrism(acrossFlats:Float,height:Float):Mesh {
        val r=acrossFlats/(sqrt(3f)); val pts=(0..5).map { i -> val a=PI/6+i*PI/3; V3((r*cos(a)).toFloat(),(r*sin(a)).toFloat(),0f) }
        val top=pts.map { V3(it.x,it.y,height) }; val center=V3(0f,0f,0f); val centerTop=V3(0f,0f,height); val tris=mutableListOf<Triangle>()
        for(i in 0..5) { val j=(i+1)%6; tris += Triangle(center,pts[j],pts[i]); tris += Triangle(centerTop,top[i],top[j]); tris += quad(pts[i],pts[j],top[j],top[i]) }
        return Mesh(tris,"Prisma hexagonal ${acrossFlats} mm entre faces × ${height} mm")
    }
    fun gear(module:Float,teeth:Int,height:Float):Mesh {
        require(teeth in 6..100) { "A engrenagem deve ter entre 6 e 100 dentes." }
        require(module>0f && height>0f) { "Módulo e altura devem ser positivos." }
        val root=module*teeth/2f-module*1.25f; val outer=module*teeth/2f+module
        require(root>0f) { "Módulo muito grande para essa quantidade de dentes." }
        // Perfil didático simplificado: quatro vértices por dente, sem involuta industrial.
        val pts=mutableListOf<V3>(); val steps=teeth*4
        for(i in 0 until steps) {
            val phase=i%4
            val r=if(phase==1 || phase==2) outer else root
            val a=2*PI*i/steps - PI/2
            pts += V3((r*cos(a)).toFloat(),(r*sin(a)).toFloat(),0f)
        }
        val top=pts.map { V3(it.x,it.y,height) }; val c=V3(0f,0f,0f); val ct=V3(0f,0f,height); val tris=mutableListOf<Triangle>()
        for(i in pts.indices) { val j=(i+1)%pts.size; tris += Triangle(c,pts[j],pts[i]); tris += Triangle(ct,top[i],top[j]); tris += quad(pts[i],pts[j],top[j],top[i]) }
        return Mesh(tris,"Engrenagem simplificada: ${teeth} dentes, módulo ${module} mm, altura ${height} mm")
    }
}

data class BuildRequest(val type:String,val x:Float,val y:Float,val z:Float,val explanation:String)
object LocalDesignAI {
    // Interpretador determinístico offline: não é um LLM e não deduz dimensões ausentes de fotos.
    fun interpret(prompt:String):BuildRequest {
        val s=prompt.lowercase()
        fun numberAfter(vararg keys:String,default:Float):Float {
            for(k in keys) { val m=Regex("${Regex.escape(k)}\\s*[:=]?\\s*(\\d+(?:[.,]\\d+)?)").find(s); if(m!=null) return m.groupValues[1].replace(',','.').toFloatOrNull() ?: default }
            return default
        }
        val x=numberAfter("diâmetro externo","diametro externo","largura","width","diâmetro","diametro","module","módulo","x",default=40f).coerceIn(1f,500f)
        val y=numberAfter("diâmetro interno","diametro interno","profundidade","comprimento","length","depth","furo","hole","y",default=20f).coerceIn(0.5f,499f)
        val z=numberAfter("altura","height","espessura","thickness","z",default=20f).coerceIn(1f,500f)
        val teeth=numberAfter("dentes","teeth",default=20f).toInt().coerceIn(6,100)
        return when {
            listOf("engrenagem","gear").any{s.contains(it)} -> BuildRequest("gear",x,teeth.toFloat(),z,"Engrenagem simplificada com $teeth dentes; perfil não involuto.")
            listOf("tubo","tube","bucha","bushing","cano").any{s.contains(it)} -> BuildRequest("tube",x,y.coerceAtMost(x-0.5f),z,"Tubo paramétrico com diâmetros externo e interno.")
            listOf("hexagonal","sextavado","porca","hexagon","nut").any{s.contains(it)} -> BuildRequest("hex",x,y,z,"Prisma hexagonal. Não inclui furo roscado.")
            listOf("cilindro","pino","cylinder","rod").any{s.contains(it)} -> BuildRequest("cylinder",x,y,z,"Cilindro maciço: diâmetro ${x} mm e altura ${z} mm.")
            else -> BuildRequest("box",x,y,z,"Bloco paramétrico: ${x} × ${y} × ${z} mm.")
        }
    }
    fun build(r:BuildRequest):Mesh = when(r.type) {
        "cylinder" -> ModelBuilder.cylinder(r.x,r.z)
        "tube" -> ModelBuilder.tube(r.x,r.y.coerceIn(0.5f,r.x-0.1f),r.z)
        "hex" -> ModelBuilder.hexPrism(r.x,r.z)
        "gear" -> ModelBuilder.gear(r.x,r.y.toInt(),r.z)
        else -> ModelBuilder.box(r.x,r.y,r.z)
    }
}
