package com.stlaicreator.app

import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.pdf.PdfDocument
import java.io.ByteArrayOutputStream
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/** Gera uma prancha PDF A4 horizontal com vista isométrica da malha e vistas de envelope. */
object TechnicalDrawingPdf {
    fun create(mesh: Mesh, request: BuildRequest, language: String, report: MeshReport): ByteArray {
        val pt = language == "pt"
        val doc = PdfDocument()
        val pageInfo = PdfDocument.PageInfo.Builder(842, 595, 1).create()
        val page = doc.startPage(pageInfo)
        val c = page.canvas
        val ink = 0xFF18202A.toInt()
        val muted = 0xFF647080.toInt()
        val accent = 0xFF5146A5.toInt()
        val thin = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = ink; style = Paint.Style.STROKE; strokeWidth = 1f }
        val bold = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = ink; textSize = 15f; typeface = android.graphics.Typeface.create("sans-serif", android.graphics.Typeface.BOLD) }
        val normal = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = ink; textSize = 10f }
        val small = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = muted; textSize = 8f }
        val heading = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = accent; textSize = 21f; typeface = android.graphics.Typeface.create("sans-serif", android.graphics.Typeface.BOLD) }
        c.drawColor(android.graphics.Color.WHITE)
        c.drawRect(22f, 22f, 820f, 573f, thin)
        c.drawText("STL AI CREATOR", 38f, 52f, heading)
        c.drawText(if (pt) "DESENHO TÉCNICO 3D • PRANCHA DO PROJETO" else "3D TECHNICAL DRAWING • PROJECT SHEET", 38f, 70f, normal)
        c.drawLine(38f, 82f, 804f, 82f, thin)
        c.drawText(mesh.description, 38f, 101f, bold)
        c.drawText(if (pt) "Unidades: mm | Representação baseada na malha STL gerada" else "Units: mm | Drawing generated from the exported STL mesh", 38f, 116f, small)

        val vertices = mesh.triangles.flatMap { listOf(it.a, it.b, it.c) }
        val minX = vertices.minOf { it.x }; val maxX = vertices.maxOf { it.x }
        val minY = vertices.minOf { it.y }; val maxY = vertices.maxOf { it.y }
        val minZ = vertices.minOf { it.z }; val maxZ = vertices.maxOf { it.z }
        val dx = max(0.01f, maxX - minX); val dy = max(0.01f, maxY - minY); val dz = max(0.01f, maxZ - minZ)

        // Isometric projection of every STL triangle edge.
        val area = RectF(45f, 145f, 480f, 470f)
        val raw = vertices.map { v -> Pair((v.x-v.y)*0.866f, (v.x+v.y)*0.5f-v.z) }
        val rx0 = raw.minOf { it.first }; val rx1 = raw.maxOf { it.first }
        val ry0 = raw.minOf { it.second }; val ry1 = raw.maxOf { it.second }
        val sx = area.width() / max(0.01f, rx1-rx0); val sy = area.height() / max(0.01f, ry1-ry0)
        val scale = min(sx, sy) * 0.78f
        val cx = area.centerX(); val cy = area.centerY()
        fun iso(v: V3): Pair<Float,Float> = Pair(cx + (((v.x-v.y)*0.866f)-(rx0+rx1)/2f)*scale, cy - (((v.x+v.y)*0.5f-v.z)-(ry0+ry1)/2f)*scale)
        val edgePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = accent; style = Paint.Style.STROKE; strokeWidth = 0.65f }
        mesh.triangles.forEach { t ->
            val p = iso(t.a); val q = iso(t.b); val r = iso(t.c)
            c.drawLine(p.first,p.second,q.first,q.second,edgePaint)
            c.drawLine(q.first,q.second,r.first,r.second,edgePaint)
            c.drawLine(r.first,r.second,p.first,p.second,edgePaint)
        }
        c.drawText(if (pt) "VISTA ISOMÉTRICA" else "ISOMETRIC VIEW", 48f, 137f, bold)

        // Orthographic projections from the actual STL triangle edges (including hidden edges).
        c.drawText(if (pt) "PROJEÇÕES ORTOGRÁFICAS DA MALHA" else "ORTHOGRAPHIC MESH PROJECTIONS", 505f, 145f, bold)
        val orthoPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = ink; style = Paint.Style.STROKE; strokeWidth = 0.8f
        }
        fun orthographic(left: Float, top: Float, width: Float, height: Float,
                         title: String, project: (V3) -> Pair<Float, Float>, dimA: String, dimB: String) {
            c.drawText(title, left, top - 7f, small)
            c.drawRect(left, top, left + width, top + height, thin)
            val projected = vertices.map(project)
            val px0 = projected.minOf { it.first }; val px1 = projected.maxOf { it.first }
            val py0 = projected.minOf { it.second }; val py1 = projected.maxOf { it.second }
            val fit = min(width * 0.82f / max(0.01f, px1-px0), height * 0.78f / max(0.01f, py1-py0))
            val ox = left + width/2f - (px0+px1)/2f*fit
            val oy = top + height/2f + (py0+py1)/2f*fit
            fun screen(v: V3): Pair<Float,Float> { val q=project(v); return Pair(ox+q.first*fit, oy-q.second*fit) }
            mesh.triangles.forEach { t ->
                val a=screen(t.a); val b=screen(t.b); val d=screen(t.c)
                c.drawLine(a.first,a.second,b.first,b.second,orthoPaint)
                c.drawLine(b.first,b.second,d.first,d.second,orthoPaint)
                c.drawLine(d.first,d.second,a.first,a.second,orthoPaint)
            }
            c.drawText(dimA, left, top+height+12f, small)
            c.drawText(dimB, left+width+5f, top+height/2f, small)
        }
        orthographic(520f,170f,205f,78f,if(pt) "FRONTAL (X-Z)" else "FRONT (X-Z)", { v -> Pair(v.x,v.z) }, "X ${fmt(dx)} mm", "Z ${fmt(dz)}")
        orthographic(520f,300f,205f,65f,if(pt) "SUPERIOR (X-Y)" else "TOP (X-Y)", { v -> Pair(v.x,v.y) }, "X ${fmt(dx)} mm", "Y ${fmt(dy)}")
        orthographic(520f,420f,125f,48f,if(pt) "LATERAL (Y-Z)" else "SIDE (Y-Z)", { v -> Pair(v.y,v.z) }, "Y ${fmt(dy)} mm", "Z ${fmt(dz)}")
        c.drawText(if(pt) "Nota: arestas ocultas também são exibidas." else "Note: hidden edges are also displayed.", 650f, 480f, small)

        c.drawLine(38f, 500f, 804f, 500f, thin)
        c.drawText(if(pt) "DADOS DO MODELO" else "MODEL DATA", 38f, 519f, bold)
        c.drawText("X ${fmt(dx)} mm    Y ${fmt(dy)} mm    Z ${fmt(dz)} mm", 38f, 536f, normal)
        c.drawText("${mesh.triangles.size} ${if(pt) "triângulos" else "triangles"} | ${if(pt) "Tipo" else "Type"}: ${request.type}", 38f, 551f, normal)
        val valid = if (report.isWatertight) (if(pt) "FECHADA (arestas)" else "CLOSED (edge test)") else (if(pt) "REVISAR MALHA" else "CHECK MESH")
        c.drawText("${if(pt) "Validação" else "Validation"}: $valid | ${if(pt) "Abertas" else "Open"}: ${report.boundaryEdges} | ${if(pt) "Não-manifold" else "Non-manifold"}: ${report.nonManifoldEdges}", 390f, 536f, normal)
        c.drawText(if(pt) "Desenho de referência. Conferir cotas, tolerâncias e fabricação no CAD/fatiador antes de produzir." else "Reference drawing. Verify dimensions, tolerances and manufacturability in CAD/slicer before production.", 390f, 551f, small)
        c.drawText("STL AI Creator • v1.5.0", 690f, 563f, small)
        doc.finishPage(page)
        val out = ByteArrayOutputStream()
        doc.writeTo(out)
        doc.close()
        return out.toByteArray()
    }

    private fun fmt(value: Float): String = String.format(java.util.Locale.US, "%.2f", value)
}
